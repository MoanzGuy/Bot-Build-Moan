const path = require("path");

module.exports = {
  BOT_NAME: "BOT BUILD APK BY @MonzapThrone",
  BOT_VERSION: "1.0",
  
  // Token bot
  BOT_TOKEN: process.env.BOT_TOKEN || "8361146625:AAEr0DANa5MLqAQ8G-kpN2YHOqizxnpEnkg",
  
  // API Telegram
  API_ID: parseInt(process.env.API_ID || "36242737"),
  API_HASH: process.env.API_HASH || "904e85ba2506348c1801cd1db421816c",
  
  // Owner & Admin
  OWNER_ID: parseInt(process.env.OWNER_ID || "7411360226"),
  ADMIN_IDS: (process.env.ADMIN_IDS || "7411360226").split(",").map(Number).filter(Boolean),
  
  // Channel
  CHANNEL_USERNAME: process.env.CHANNEL_USERNAME || "infoweb2apk",
  
  // GitHub & Vercel
  GITHUB_TOKEN: process.env.GITHUB_TOKEN || "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",
  GITHUB_USERNAME: process.env.GITHUB_USERNAME || "zenoss2311",
  VERCEL_TOKEN: process.env.VERCEL_TOKEN || "vcp_6CT9iTZ7LfG6AYd9Dr0yj0ALR9m8l8AHx6KiNMl1Ayudjc27IP3Gd0in",
  VERCEL_TEAM_ID: process.env.VERCEL_TEAM_ID || "team_2sxYT90u2v8CJbAZ2F8FW7za",
  
  // PHOTO - PAKAI FILE LOKAL
  WELCOME_PHOTO: path.join(__dirname, "images", "welcome.jpg"),
  PHOTO_BUILD_APK: path.join(__dirname, "images", "build.jpg"),
  PHOTO_WEB2APK: path.join(__dirname, "images", "web2apk.jpg"),
  PHOTO_DEPLOY_WEB: path.join(__dirname, "images", "deploy.jpg"),
  PHOTO_ENC_HTML: path.join(__dirname, "images", "enc_html.jpg"),
  PHOTO_ENC_JS: path.join(__dirname, "images", "enc_js.jpg"),
  PHOTO_MOD_DOMAIN: path.join(__dirname, "images", "mod_domain.jpg"),
  PHOTO_MOD_COLOR: path.join(__dirname, "images", "mod_color.jpg"),
  PHOTO_MOD_ICON: path.join(__dirname, "images", "mod_icon.jpg"),
  PHOTO_MOD_NAME: path.join(__dirname, "images", "mod_name.jpg"),
  PHOTO_NEW_USER: path.join(__dirname, "images", "new_user.jpg"),
  PHOTO_REPORT_BUG: path.join(__dirname, "images", "report.jpg"),
  
  // Directories
  TMP_DIR: "./tmp",
  
  // Build settings
  BUILD_TIMEOUT_MS: 30 * 60 * 1000,
  POLL_INTERVAL_MS: 7000,
  WEB2APK_MAINTENANCE: false,
};